import sys
from sqlitedict import *
from PyQt5.QtWidgets import QWidget, QApplication, QMainWindow, QPushButton, QLineEdit, QLabel, \
                            QVBoxLayout, QDialog, QMessageBox
from PyQt5.QtGui import QIcon, QFont, QPixmap, QPalette, QBrush, QImage
from PyQt5.QtCore import Qt, pyqtSlot
from PyQt5 import QtGui

class AEOCode(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Analytical Engine Order Code")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('AnalyticalEngineOrderCode.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog1 = QLabel("Analytical Engine Order Code", self)
        self.prog1.move(80,70)
        self.prog1.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image1 = QLabel(self)
        pixmap = QPixmap('AnalyticalEngineOrderCode.png')
        self.image1.setPixmap(pixmap)
        self.image1.move(460,50)
        self.image1.resize(300,300)

        self.descrip1 = QLabel("     The Analytical Engine was to be a \ngeneral-purpose, fully program-controlled, \nautomatic mechanical digital computer. It \nwould be able to perform any calculation \nset before it. The machine was designed to \nconsist of four components: the mill, the \nstore, the reader, and the printer.",self)
        self.descrip1.move(40,150)
        self.descrip1.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc1 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc1.move(20,320)
        self.year_disc1.setFont(QtGui.QFont('Impact', 14))

        self.year1 = QLabel("1837",self)
        self.year1.move(170,322)
        self.year1.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by1 = QLabel("DISCOVERED BY:",self)
        self.disc_by1.move(20,370)
        self.disc_by1.setFont(QtGui.QFont('Impact', 14))

        self.author1 = QLabel("Charles Babbage",self)
        self.author1.move(150,372)
        self.author1.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm1 = QLabel("PARADIGM:",self)
        self.paradigm1.move(20,420)
        self.paradigm1.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type1 = QLabel("Mechanical Programming Language",self)
        self.paradigm_type1.move(120,422)
        self.paradigm_type1.setFont(QtGui.QFont('Consolas', 13))

class ENIACSCode(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ENIAC Short Code")
        self.setGeometry(250,70,810,600)
        self.setWindowIcon(QIcon('ENIACShortCode.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog2 = QLabel("   Electronic Numerical Integrator \nand Computer (ENIAC) Short Code", self)
        self.prog2.move(60,60)
        self.prog2.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image2 = QLabel(self)
        pixmap = QPixmap('ENIACShortCode.png')
        self.image2.setPixmap(pixmap)
        self.image2.move(500,50)
        self.image2.resize(245,300)

        self.descrip2 = QLabel("     The Electronic Numerical Integrator and \nComputer (ENIAC) Short Code was one of the first \nhigher-level languages ever developed for an \nelectronic computer. Unlike machine code, Short \nCode statements represented mathematic expressions \nrather than a machine instruction. Also known as \nan automatic programming, the source code was not \ncompiled but executed through an interpreter to \nsimplify the programming process; the execution \ntime was much slower though.",self)
        self.descrip2.move(40,150)
        self.descrip2.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc2 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc2.move(20,380)
        self.year_disc2.setFont(QtGui.QFont('Impact', 14))

        self.year2 = QLabel("1949",self)
        self.year2.move(170,382)
        self.year2.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by2 = QLabel("DISCOVERED BY:",self)
        self.disc_by2.move(20,430)
        self.disc_by2.setFont(QtGui.QFont('Impact', 14))

        self.author2 = QLabel("John Mauchly and J. Presper Eckert, Jr.",self)
        self.author2.move(150,432)
        self.author2.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm2 = QLabel("PARADIGM:",self)
        self.paradigm2.move(20,480)
        self.paradigm2.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type2 = QLabel("Mechanical Programming Language",self)
        self.paradigm_type2.move(120,482)
        self.paradigm_type2.setFont(QtGui.QFont('Consolas', 13))

class Fortran(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fortran")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Fortran.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog3 = QLabel("Formula Translation (FORTRAN)", self)
        self.prog3.move(60,70)
        self.prog3.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image3 = QLabel(self)
        pixmap = QPixmap('Fortran.png')
        self.image3.setPixmap(pixmap)
        self.image3.move(460,50)
        self.image3.resize(300,300)

        self.descrip3 = QLabel("     The FORmula TRANslation  was an \nimperative programming language that is \nespecially suited to numeric computation and \nscientific computing. It was designed to \nallow easy translation of math formulas into \ncode.",self)
        self.descrip3.move(40,140)
        self.descrip3.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc3 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc3.move(20,300)
        self.year_disc3.setFont(QtGui.QFont('Impact', 14))

        self.year3 = QLabel("1954",self)
        self.year3.move(170,302)
        self.year3.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by3 = QLabel("DISCOVERED BY:",self)
        self.disc_by3.move(20,350)
        self.disc_by3.setFont(QtGui.QFont('Impact', 14))

        self.author3 = QLabel("John Backus",self)
        self.author3.move(150,352)
        self.author3.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm3 = QLabel("PARADIGM:",self)
        self.paradigm3.move(20,400)
        self.paradigm3.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type1 = QLabel("Imperative Programming Language",self)
        self.paradigm_type1.move(110,402)
        self.paradigm_type1.setFont(QtGui.QFont('Consolas', 13))

class ALGOL(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ALGOL")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('ALGOL.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog4 = QLabel("Algorithm Language (ALGOL)", self)
        self.prog4.move(60,60)
        self.prog4.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image4 = QLabel(self)
        pixmap = QPixmap('ALGOL.png')
        self.image4.setPixmap(pixmap)
        self.image4.move(450,100)
        self.image4.resize(300,96)

        self.descrip4 = QLabel("     The ALGOrithm Language (ALGOL) it was \ngreatly influenced many other languages and \nwas the standard method for algorithm \ndescription. It was arguably the most \ninfluential of the four high-level programming \nlanguages among which it was roughly contemporary: \nFORTRAN, Lisp, and COBOL. Also, it was designed \nto avoid some of the perceived problems with FORTRAN.",self)
        self.descrip4.move(40,120)
        self.descrip4.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc4 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc4.move(20,310)
        self.year_disc4.setFont(QtGui.QFont('IMPACT', 14))

        self.year4 = QLabel("Late 1950's",self)
        self.year4.move(170,312)
        self.year4.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by4 = QLabel("DISCOVERED BY:",self)
        self.disc_by4.move(20,360)
        self.disc_by4.setFont(QtGui.QFont('Impact', 14))

        self.author4 = QLabel("Alan J. Perlis",self)
        self.author4.move(150,362)
        self.author4.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm4 = QLabel("PARADIGM:",self)
        self.paradigm4.move(20,410)
        self.paradigm4.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type4 = QLabel("Imperative Programming Language",self)
        self.paradigm_type4.move(110,412)
        self.paradigm_type4.setFont(QtGui.QFont('Consolas', 13))

class COBOL(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("COBOL")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('COBOL.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog5 = QLabel("Common Business-Oriented\n     Language (COBOL)", self)
        self.prog5.move(60,60)
        self.prog5.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image5 = QLabel(self)
        pixmap = QPixmap('COBOL.png')
        self.image5.setPixmap(pixmap)
        self.image5.move(450,100)
        self.image5.resize(300,96)

        self.descrip5 = QLabel("     The Common Business-Oriented Language \nis a High-level computer programming language, \none of the first widely used languages and \nfor many years the most popular language \nin the business community.",self)
        self.descrip5.move(40,150)
        self.descrip5.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc5 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc5.move(20,280)
        self.year_disc5.setFont(QtGui.QFont('Impact', 14))

        self.year5 = QLabel("1959",self)
        self.year5.move(170,282)
        self.year5.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by5 = QLabel("DISCOVERED BY:",self)
        self.disc_by5.move(20,330)
        self.disc_by5.setFont(QtGui.QFont('Impact', 14))

        self.author5 = QLabel("Grace Hopper",self)
        self.author5.move(150,332)
        self.author5.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm5 = QLabel("PARADIGM:",self)
        self.paradigm5.move(20,380)
        self.paradigm5.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type5 = QLabel("Imperative Programming Language",self)
        self.paradigm_type5.move(110,382)
        self.paradigm_type5.setFont(QtGui.QFont('Consolas', 13))

class LISP(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LISP")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('LISP.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog6 = QLabel("List Processor (LISP)", self)
        self.prog6.move(120,70)
        self.prog6.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image6 = QLabel(self)
        pixmap = QPixmap('LISP.png')
        self.image6.setPixmap(pixmap)
        self.image6.move(440,50)
        self.image6.resize(300,300)

        self.descrip6 = QLabel("     The LISt Processor (LISP) is the \nsecond-oldest programming language still \nin modern use, younger by one year than \nFortran. Lisp was used in AI (artificial \nintelligence) research starting in 1958, \nand is still used today.",self)
        self.descrip6.move(40,150)
        self.descrip6.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc6 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc6.move(20,300)
        self.year_disc6.setFont(QtGui.QFont('Impact', 14))

        self.year6 = QLabel("1958",self)
        self.year6.move(170,302)
        self.year6.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by6 = QLabel("DISCOVERED BY:",self)
        self.disc_by6.move(20,350)
        self.disc_by6.setFont(QtGui.QFont('Impact', 14))

        self.author6 = QLabel("John McCarthy",self)
        self.author6.move(150,352)
        self.author6.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm6 = QLabel("PARADIGM:",self)
        self.paradigm6.move(20,400)
        self.paradigm6.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type6 = QLabel("Functional Programming Language",self)
        self.paradigm_type6.move(110,402)
        self.paradigm_type6.setFont(QtGui.QFont('Consolas', 13))

class SNOBOL(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SNOBOL")
        self.setGeometry(250,70,800,600)
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog7 = QLabel("String Oriented and Symbolic Language \n                      (SNOBOL)", self)
        self.prog7.move(170,60)
        self.prog7.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.descrip7 = QLabel("     The StriNg Oriented and symBOlic Language (SNOBOL) supports a number of \nbuilt-in data types, such as integers and limited precision real numbers, \nstrings, patterns, arrays, and tables (associative arrays), and also allows the \nprogrammer to define additional data types and new functions. ",self)
        self.descrip7.move(40,150)
        self.descrip7.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc7 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc7.move(20,270)
        self.year_disc7.setFont(QtGui.QFont('Impact', 14))

        self.year7 = QLabel("1962",self)
        self.year7.move(170,272)
        self.year7.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by7 = QLabel("DISCOVERED BY:",self)
        self.disc_by7.move(20,320)
        self.disc_by7.setFont(QtGui.QFont('Impact', 14))

        self.author7 = QLabel("David J. Farber, Ralph E. Griswold and Ivan P. Polonsky",self)
        self.author7.move(150,322)
        self.author7.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm7 = QLabel("PARADIGM:",self)
        self.paradigm7.move(20,370)
        self.paradigm7.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type7 = QLabel("Imperative Programming Language",self)
        self.paradigm_type7.move(110,372)
        self.paradigm_type7.setFont(QtGui.QFont('Consolas', 13))

class BASIC(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BASIC")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('BASIC.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog8 = QLabel("Beginner’s All-purpose Symbolic \n     Instruction Code (BASIC)", self)
        self.prog8.move(60,70)
        self.prog8.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image8 = QLabel(self)
        pixmap = QPixmap('BASIC.png')
        self.image8.setPixmap(pixmap)
        self.image8.move(450,50)
        self.image8.resize(300,300)

        self.descrip8 = QLabel("     The Beginner’s All-purpose Symbolic \nInstruction Code (BASIC) were one of the \nsimplest high-level languages, with commands \nsimilar to English, it can be learned with \nrelative ease even by school children and \nnovice programmers. BASIC was traditionally \none of the most commonly used computer \nprogramming languages, considered an easy \nstep for students to learn before more \npowerful languages such as FORTRAN.",self)
        self.descrip8.move(40,170)
        self.descrip8.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc8 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc8.move(20,400)
        self.year_disc8.setFont(QtGui.QFont('Impact', 14))

        self.year8 = QLabel("1964",self)
        self.year8.move(170,402)
        self.year8.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by8 = QLabel("DISCOVERED BY:",self)
        self.disc_by8.move(20,450)
        self.disc_by8.setFont(QtGui.QFont('Impact', 14))

        self.author8 = QLabel("John George Kemeny and Tom Kurtz ",self)
        self.author8.move(150,452)
        self.author8.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm8 = QLabel("PARADIGM:",self)
        self.paradigm8.move(20,500)
        self.paradigm8.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type8 = QLabel("Imperative Programming Language",self)
        self.paradigm_type8.move(110,502)
        self.paradigm_type8.setFont(QtGui.QFont('Consolas', 13))

class Simula(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Simula")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Simula.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog9 = QLabel("Simula", self)
        self.prog9.move(200,70)
        self.prog9.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image9 = QLabel(self)
        pixmap = QPixmap('Simula.png')
        self.image9.setPixmap(pixmap)
        self.image9.move(450,30)
        self.image9.resize(300,300)

        self.descrip9 = QLabel("     The Simula is considered the first \nobject-oriented programming language. Simula \nis the name of two simulation programming \nlanguages, Simula I and Simula 67. Simula 67 \nintroduced objects, classes, inheritance and \nsubclasses, virtual procedures, coroutines, \nand discrete event simulation, and features \ngarbage collection. SIMULA I was born, a \nspecial purpose programming language (similar \nto ALGOL 60) for simulating discrete event \nsystems.",self)
        self.descrip9.move(40,140)
        self.descrip9.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc9 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc9.move(20,400)
        self.year_disc9.setFont(QtGui.QFont('Impact', 14))

        self.year9 = QLabel("1960's",self)
        self.year9.move(170,402)
        self.year9.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by9 = QLabel("DISCOVERED BY:",self)
        self.disc_by9.move(20,450)
        self.disc_by9.setFont(QtGui.QFont('Impact', 14))

        self.author9 = QLabel("Ole-Johan Dahl and Kristen Nygaard",self)
        self.author9.move(150,452)
        self.author9.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm9 = QLabel("PARADIGM:",self)
        self.paradigm9.move(20,500)
        self.paradigm9.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type9 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type9.move(110,502)
        self.paradigm_type9.setFont(QtGui.QFont('Consolas', 13))

class PL1(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PL/1")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('PL1.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog10 = QLabel("Programming Language One (PL/1)", self)
        self.prog10.move(50,70)
        self.prog10.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image10 = QLabel(self)
        pixmap = QPixmap('PL1.png')
        self.image10.setPixmap(pixmap)
        self.image10.move(460,50)
        self.image10.resize(300,300)

        self.descrip10 = QLabel("     The Programming Language One (PL/1 ) is a \nprocedural, imperative computer programming \nlanguage developed and published by IBM. It is \ndesigned for scientific, engineering, business \nand system programming. PL/I was intended as an \nall-purpose language to combine the scientific \nabilities of FORTRAN with the business \ncapabilities of COBOL, plus additional \nfacilities for systems programming.",self)
        self.descrip10.move(40,140)
        self.descrip10.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc10 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc10.move(20,350)
        self.year_disc10.setFont(QtGui.QFont('Impact', 14))

        self.year10 = QLabel("1964",self)
        self.year10.move(170,352)
        self.year10.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by10 = QLabel("DISCOVERED BY:",self)
        self.disc_by10.move(20,400)
        self.disc_by10.setFont(QtGui.QFont('Impact', 14))

        self.author10 = QLabel("Adam Michael Wood",self)
        self.author10.move(150,402)
        self.author10.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm10 = QLabel("PARADIGM:",self)
        self.paradigm10.move(20,450)
        self.paradigm10.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type10 = QLabel("Imperative Programming Language",self)
        self.paradigm_type10.move(110,452)
        self.paradigm_type10.setFont(QtGui.QFont('Consolas', 13))

class B(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("B")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('B.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog11 = QLabel("B", self)
        self.prog11.move(200,70)
        self.prog11.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image11 = QLabel(self)
        pixmap = QPixmap('B.png')
        self.image11.setPixmap(pixmap)
        self.image11.move(440,50)
        self.image11.resize(300,300)

        self.descrip11 = QLabel("     The B was designed for recursive, \nnon-numeric, machine-independent \napplications, such as system and language \nsoftware. It was a typeless language, \nwith the only data type being the \nunderlying machine's natural memory word \nformat, whatever that might be.",self)
        self.descrip11.move(40,150)
        self.descrip11.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc11 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc11.move(20,330)
        self.year_disc11.setFont(QtGui.QFont('Impact', 14))

        self.year11 = QLabel("1969",self)
        self.year11.move(170,332)
        self.year11.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by11 = QLabel("DISCOVERED BY:",self)
        self.disc_by11.move(20,380)
        self.disc_by11.setFont(QtGui.QFont('Impact', 14))

        self.author11 = QLabel("Dennis Ritchie",self)
        self.author11.move(150,382)
        self.author11.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm11 = QLabel("PARADIGM:",self)
        self.paradigm11.move(20,430)
        self.paradigm11.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type11 = QLabel("Imperative Programming Language",self)
        self.paradigm_type11.move(110,432)
        self.paradigm_type11.setFont(QtGui.QFont('Consolas', 13))

class Logo(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Logo")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('LOGO.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog12 = QLabel("Logo", self)
        self.prog12.move(200,70)
        self.prog12.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image12 = QLabel(self)
        pixmap = QPixmap('Logo.png')
        self.image12.setPixmap(pixmap)
        self.image12.move(440,50)
        self.image12.resize(300,300)

        self.descrip12 = QLabel("     The Logo Programming Language, a \ndialect of Lisp, was designed as a tool \nfor learning. Its features - interactivity, \nmodularity, extensibility, flexibility of \ndata types - follow from this goal. Also, \nLogo exists solely to introduce children \nto basic programming concepts and teach \nprogramming.",self)
        self.descrip12.move(40,150)
        self.descrip12.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc12 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc12.move(20,340)
        self.year_disc12.setFont(QtGui.QFont('Impact', 14))

        self.year12 = QLabel("1967",self)
        self.year12.move(170,342)
        self.year12.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by12 = QLabel("DISCOVERED BY:",self)
        self.disc_by12.move(20,390)
        self.disc_by12.setFont(QtGui.QFont('Impact', 14))

        self.author12 = QLabel("Wally Feurzeig",self)
        self.author12.move(150,392)
        self.author12.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm12 = QLabel("PARADIGM:",self)
        self.paradigm12.move(20,440)
        self.paradigm12.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type12 = QLabel("Functional Programming Language",self)
        self.paradigm_type12.move(110,442)
        self.paradigm_type12.setFont(QtGui.QFont('Consolas', 13))

class Forth(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Forth")
        self.setGeometry(250,70,800,600)
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog13 = QLabel("Forth", self)
        self.prog13.move(350,70)
        self.prog13.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.descrip13 = QLabel("     The Forth is an imperative stack-based computer programming language and \nenvironment. Forth features include structured programming, reflection (the \nability to examine and modify program structure during execution), concatenative \nprogramming (functions are composed with juxtaposition) and extensibility (the \nprogrammer can create new commands).",self)
        self.descrip13.move(40,130)
        self.descrip13.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc13 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc13.move(20,270)
        self.year_disc13.setFont(QtGui.QFont('Impact', 14))

        self.year13 = QLabel("1968-1973",self)
        self.year13.move(170,270)
        self.year13.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by13 = QLabel("DISCOVERED BY:",self)
        self.disc_by13.move(20,320)
        self.disc_by13.setFont(QtGui.QFont('Impact', 14))

        self.author13 = QLabel("Charles H. Moore",self)
        self.author13.move(150,320)
        self.author13.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm13 = QLabel("PARADIGM:",self)
        self.paradigm13.move(20,370)
        self.paradigm13.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type13 = QLabel("Imperative Programming Language",self)
        self.paradigm_type13.move(110,370)
        self.paradigm_type13.setFont(QtGui.QFont('Consolas', 13))

class Pascal(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pascal")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Pascal.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog14 = QLabel("Pascal", self)
        self.prog14.move(180,70)
        self.prog14.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image14 = QLabel(self)
        pixmap = QPixmap('Pascal.png')
        self.image14.setPixmap(pixmap)
        self.image14.move(440,100)
        self.image14.resize(300,99)

        self.descrip14 = QLabel("     The Pascal is an imperative and \nprocedural programming language developed \nabout 1970 by Niklaus Wirth of Switzerland \nto teach structured programming and data \nstructuring, which emphasizes the orderly \nuse of conditional and loop control \nstructures without GOTO statements.",self)
        self.descrip14.move(40,130)
        self.descrip14.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc14 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc14.move(20,300)
        self.year_disc14.setFont(QtGui.QFont('Impact', 14))

        self.year14 = QLabel("1960's",self)
        self.year14.move(170,302)
        self.year14.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by14 = QLabel("DISCOVERED BY:",self)
        self.disc_by14.move(20,350)
        self.disc_by14.setFont(QtGui.QFont('Impact', 14))

        self.author14 = QLabel("Blaise Pascal",self)
        self.author14.move(150,352)
        self.author14.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm14 = QLabel("PARADIGM:",self)
        self.paradigm14.move(20,400)
        self.paradigm14.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type14 = QLabel("Imperative Programming Language",self)
        self.paradigm_type14.move(110,402)
        self.paradigm_type14.setFont(QtGui.QFont('Consolas', 13))

class Smalltalk(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Smalltalk")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Smalltalk.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog15 = QLabel("Smalltalk", self)
        self.prog15.move(180,70)
        self.prog15.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image15 = QLabel(self)
        pixmap = QPixmap('Smalltalk.png')
        self.image15.setPixmap(pixmap)
        self.image15.move(480,80)
        self.image15.resize(300,300)

        self.descrip15 = QLabel("     The Smalltalk is the second object-oriented \nprogramming language and the first true IDE. Smalltalk \nis an object oriented, dynamically typed reflective \nprogramming language. Smalltalk was created as the \nlanguage underpinning the ‘new world’ of computing \nexemplified by ‘human–computer symbiosis’.",self)
        self.descrip15.move(40,130)
        self.descrip15.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc15 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc15.move(20,300)
        self.year_disc15.setFont(QtGui.QFont('Impact', 14))

        self.year15 = QLabel("1972",self)
        self.year15.move(170,302)
        self.year15.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by15 = QLabel("DISCOVERED BY:",self)
        self.disc_by15.move(20,350)
        self.disc_by15.setFont(QtGui.QFont('Impact', 14))

        self.author15 = QLabel("Alan Kay, Dan Ingalls and Adele Goldberg",self)
        self.author15.move(150,352)
        self.author15.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm15 = QLabel("PARADIGM:",self)
        self.paradigm15.move(20,400)
        self.paradigm15.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type15 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type15.move(110,402)
        self.paradigm_type15.setFont(QtGui.QFont('Consolas', 13))

class SQL(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SQL")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('sql.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog16 = QLabel("Structured Query Language (SQL)", self)
        self.prog16.move(50,70)
        self.prog16.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image16 = QLabel(self)
        pixmap = QPixmap('sql.png')
        self.image16.setPixmap(pixmap)
        self.image16.move(460,50)
        self.image16.resize(300,300)

        self.descrip16 = QLabel("     The Structured Query Language (SQL) is a \ndomain-specific language used in programming \nand designed for managing data held in a \nrelational database management system, or for \nstream processing in a relational data stream \nmanagement system. ",self)
        self.descrip16.move(40,140)
        self.descrip16.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc16 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc16.move(20,290)
        self.year_disc16.setFont(QtGui.QFont('Impact', 14))

        self.year16 = QLabel("1970's",self)
        self.year16.move(170,292)
        self.year16.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by16 = QLabel("DISCOVERED BY:",self)
        self.disc_by16.move(20,340)
        self.disc_by16.setFont(QtGui.QFont('Impact', 14))

        self.author16 = QLabel("Donald D. Chamberlin and Raymond Boyce",self)
        self.author16.move(150,342)
        self.author16.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm16 = QLabel("PARADIGM:",self)
        self.paradigm16.move(20,390)
        self.paradigm16.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type16 = QLabel("Declarative Programming Language",self)
        self.paradigm_type16.move(110,392)
        self.paradigm_type16.setFont(QtGui.QFont('Consolas', 13))

class Prolog(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PROLOG")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('prolog.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog17 = QLabel("Programming in Logic (PROLOG)", self)
        self.prog17.move(70,70)
        self.prog17.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image17 = QLabel(self)
        pixmap = QPixmap('prolog.png')
        self.image17.setPixmap(pixmap)
        self.image17.move(440,100)
        self.image17.resize(300,73)

        self.descrip17 = QLabel("     The Programming in Logic (PROLOG) is \na logic programming language associated \nwith artificial intelligence and \ncomputational linguistics.",self)
        self.descrip17.move(40,150)
        self.descrip17.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc17 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc17.move(20,260)
        self.year_disc17.setFont(QtGui.QFont('Impact', 14))

        self.year17 = QLabel("1970's",self)
        self.year17.move(170,262)
        self.year17.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by17 = QLabel("DISCOVERED BY:",self)
        self.disc_by17.move(20,310)
        self.disc_by17.setFont(QtGui.QFont('Impact', 14))

        self.author17 = QLabel("Alain Colmerauer",self)
        self.author17.move(150,312)
        self.author17.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm17 = QLabel("PARADIGM:",self)
        self.paradigm17.move(20,360)
        self.paradigm17.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type17 = QLabel("Declarative Programming Language",self)
        self.paradigm_type17.move(110,362)
        self.paradigm_type17.setFont(QtGui.QFont('Consolas', 13))

class C(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("C")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('C.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog18 = QLabel("C", self)
        self.prog18.move(240,70)
        self.prog18.setFont(QtGui.QFont('Berlin Sans FB',20))

        self.image18 = QLabel(self)
        pixmap = QPixmap('C.png')
        self.image18.setPixmap(pixmap)
        self.image18.move(470,50)
        self.image18.resize(300,300)

        self.descrip18 = QLabel("     The C Programming Language is a high-level \nand general-purpose programming language that is \nideal for developing firmware or portable \napplications. C was designed as a minimalist \nlanguage to be used in writing operating \nsystems for minicomputers.",self)
        self.descrip18.move(40,150)
        self.descrip18.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc18 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc18.move(20,300)
        self.year_disc18.setFont(QtGui.QFont('Impact', 14))

        self.year18 = QLabel("1972",self)
        self.year18.move(170,302)
        self.year18.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by18 = QLabel("DISCOVERED BY:",self)
        self.disc_by18.move(20,350)
        self.disc_by18.setFont(QtGui.QFont('Impact', 14))

        self.author18 = QLabel("Dennis Ritchie",self)
        self.author18.move(150,352)
        self.author18.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm18 = QLabel("PARADIGM:",self)
        self.paradigm18.move(20,400)
        self.paradigm18.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type18 = QLabel("Imperative Programming Language",self)
        self.paradigm_type18.move(110,402)
        self.paradigm_type18.setFont(QtGui.QFont('Consolas', 13))

class Modula(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Modula")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Modula.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog19 = QLabel("Modula", self)
        self.prog19.move(200,70)
        self.prog19.setFont(QtGui.QFont('Berlin Sans FB', 20))
       
        self.image19 = QLabel(self)
        pixmap = QPixmap('Modula.png')
        self.image19.setPixmap(pixmap)
        self.image19.move(470,50)
        self.image19.resize(300,300)

        self.descrip19 = QLabel("      The Modula is an imperative programming \nlanguages developed in the 1970s by Niklaus \nWirth; who also created the Pascal programming \nlanguage. Modula allows code to be compiled in \ndiscrete units called modules, a technique \ntoday known as modular programming.",self)
        self.descrip19.move(40,150)
        self.descrip19.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc19 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc19.move(20,300)
        self.year_disc19.setFont(QtGui.QFont('Impact', 14))

        self.year19 = QLabel("1970's",self)
        self.year19.move(170,302)
        self.year19.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by19 = QLabel("DISCOVERED BY:",self)
        self.disc_by19.move(20,350)
        self.disc_by19.setFont(QtGui.QFont('Impact', 14))

        self.author19 = QLabel("Niklaus Wirth",self)
        self.author19.move(150,352)
        self.author19.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm19 = QLabel("PARADIGM:",self)
        self.paradigm19.move(20,400)
        self.paradigm19.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type19 = QLabel("Imperative Programming Language",self)
        self.paradigm_type19.move(110,402)
        self.paradigm_type19.setFont(QtGui.QFont('Consolas', 13))

class ML(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ML")
        self.setGeometry(250,70,800,600)
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog20 = QLabel("Meta Language (ML)", self)
        self.prog20.move(270,70)
        self.prog20.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.descrip20 = QLabel("     The Meta Language (ML) is a general-purpose functional programming \nlanguage. It has roots in Lisp, and has been characterized as ‘Lisp with types’. \nML is a statically-scoped functional programming language. It is known for its \nuse of the polymorphic Hindley–Milner type system, which automatically assigns \nthe types of most expressions without requiring explicit type annotations, and \nensures type safety.",self)
        self.descrip20.move(40,130)
        self.descrip20.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc20 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc20.move(20,300)
        self.year_disc20.setFont(QtGui.QFont('Impact', 14))

        self.year20 = QLabel("1973",self)
        self.year20.move(170,302)
        self.year20.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by20 = QLabel("DISCOVERED BY:",self)
        self.disc_by20.move(20,350)
        self.disc_by20.setFont(QtGui.QFont('Impact', 14))

        self.author20 = QLabel("Robin Milner",self)
        self.author20.move(150,352)
        self.author20.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm20 = QLabel("PARADIGM:",self)
        self.paradigm20.move(20,400)
        self.paradigm20.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type20 = QLabel("Functional Programming Language",self)
        self.paradigm_type20.move(110,402)
        self.paradigm_type20.setFont(QtGui.QFont('Consolas', 13))

class Scheme(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Scheme")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Scheme.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog21 = QLabel("Scheme", self)
        self.prog21.move(200,70)
        self.prog21.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image21 = QLabel(self)
        pixmap = QPixmap('Scheme.png')
        self.image21.setPixmap(pixmap)
        self.image21.move(480,50)
        self.image21.resize(300,300)

        self.descrip21 = QLabel("     The Scheme is a programming language that \nsupports multiple paradigms, including functional \nand imperative programming. Scheme follows a \nminimalist design philosophy, specifying a small \nstandard core with powerful tools for language \nextension.",self)
        self.descrip21.move(40,130)
        self.descrip21.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc21 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc21.move(20,290)
        self.year_disc21.setFont(QtGui.QFont('Impact', 14))

        self.year21 = QLabel("1975",self)
        self.year21.move(170,292)
        self.year21.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by21 = QLabel("DISCOVERED BY:",self)
        self.disc_by21.move(20,340)
        self.disc_by21.setFont(QtGui.QFont('Impact', 14))

        self.author21 = QLabel("Guy Steele",self)
        self.author21.move(150,342)
        self.author21.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm21 = QLabel("PARADIGM:",self)
        self.paradigm21.move(20,390)
        self.paradigm21.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type21 = QLabel("Functional Programming Language",self)
        self.paradigm_type21.move(110,392)
        self.paradigm_type21.setFont(QtGui.QFont('Consolas', 13))

class Ada(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ada")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Ada.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog22 = QLabel("Ada", self)
        self.prog22.move(200,70)
        self.prog22.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image22 = QLabel(self)
        pixmap = QPixmap('Ada.png')
        self.image22.setPixmap(pixmap)
        self.image22.move(440,50)
        self.image22.resize(300,326)

        self.descrip22 = QLabel("     Ada is a structured, statically typed, \nimperative, and object-oriented high-level \nprogramming language, extended from Pascal \nand other languages. It has built-in language \nsupport for design-by-contract, extremely \nstrong typing, explicit concurrency, tasks, \nsynchronous message passing, protected objects, \nand non-determinism. Ada improves code safety \nand maintainability by using the compiler to \nfind errors in favor of runtime errors.",self)
        self.descrip22.move(40,150)
        self.descrip22.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc22 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc22.move(20,380)
        self.year_disc22.setFont(QtGui.QFont('Impact', 14))

        self.year22 = QLabel("1977",self)
        self.year22.move(170,382)
        self.year22.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by22 = QLabel("DISCOVERED BY:",self)
        self.disc_by22.move(20,430)
        self.disc_by22.setFont(QtGui.QFont('Impact', 14))

        self.author22 = QLabel("Jean Ichbiah",self)
        self.author22.move(150,432)
        self.author22.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm22 = QLabel("PARADIGM:",self)
        self.paradigm22.move(20,480)
        self.paradigm22.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type22 = QLabel("Concurrent Programming Language",self)
        self.paradigm_type22.move(110,482)
        self.paradigm_type22.setFont(QtGui.QFont('Consolas', 13))

class CPP(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("C++")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('CPP.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog23 = QLabel("C++", self)
        self.prog23.move(250,70)
        self.prog23.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image23 = QLabel(self)
        pixmap = QPixmap('CPP.png')
        self.image23.setPixmap(pixmap)
        self.image23.move(480,50)
        self.image23.resize(267,300)

        self.descrip23 = QLabel("     The C++ is a general-purpose \nobject-oriented programming language and is an \nextension of the C language. The language has \nexpanded significantly over time, and modern \nC++ has object oriented, generic, and functional \nfeatures in addition to facilities for low-level \nmemory manipulation.",self)
        self.descrip23.move(40,130)
        self.descrip23.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc23 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc23.move(20,300)
        self.year_disc23.setFont(QtGui.QFont('Impact', 14))

        self.year23 = QLabel("1985",self)
        self.year23.move(170,302)
        self.year23.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by23 = QLabel("DISCOVERED BY:",self)
        self.disc_by23.move(20,350)
        self.disc_by23.setFont(QtGui.QFont('Impact', 14))

        self.author23 = QLabel("Bjarne Stroustrup",self)
        self.author23.move(150,352)
        self.author23.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm23 = QLabel("PARADIGM:",self)
        self.paradigm23.move(20,400)
        self.paradigm23.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type23 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type23.move(110,402)
        self.paradigm_type23.setFont(QtGui.QFont('Consolas', 13))

class Eiffel(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Eiffel")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Eiffel.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog24 = QLabel("Eiffel", self)
        self.prog24.move(230,70)
        self.prog24.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image24 = QLabel(self)
        pixmap = QPixmap('Eiffel.png')
        self.image24.setPixmap(pixmap)
        self.image24.move(450,100)
        self.image24.resize(300,62)

        self.descrip24 = QLabel("     The Eiffel is a statically typed \nobject-oriented programming language closely \nrelated with the programming method of the \nsame name. Both are based on a set of principles \nlike Design by Contract, Command-Query Separation, \nUniform Access, etc.",self)
        self.descrip24.move(40,130)
        self.descrip24.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc24 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc24.move(20,280)
        self.year_disc24.setFont(QtGui.QFont('Impact', 14))
        
        self.year24 = QLabel("1986",self)
        self.year24.move(170,282)
        self.year24.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by24 = QLabel("DISCOVERED BY:",self)
        self.disc_by24.move(20,330)
        self.disc_by24.setFont(QtGui.QFont('Impact', 14))

        self.author24 = QLabel("Bertrand Meyer",self)
        self.author24.move(150,332)
        self.author24.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm24 = QLabel("PARADIGM:",self)
        self.paradigm24.move(20,380)
        self.paradigm24.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type24 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type24.move(110,382)
        self.paradigm_type24.setFont(QtGui.QFont('Consolas', 13))

class ObjC(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Objective C")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('ObjectiveC.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog25 = QLabel("Objective C", self)
        self.prog25.move(200,70)
        self.prog25.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image25 = QLabel(self)
        pixmap = QPixmap('ObjectiveC.png')
        self.image25.setPixmap(pixmap)
        self.image25.move(450,50)
        self.image25.resize(300,300)

        self.descrip25 = QLabel("     The Objective-C is a general-purpose, \nobject-oriented programming language that adds \nSmalltalk-style messaging to the C programming \nlanguage. It was the main programming language \nsupported by Apple for macOS, iOS, and their \nrespective application programming interfaces \n(APIs), Cocoa and Cocoa Touch, until the \nintroduction of Swift in 2014.",self)
        self.descrip25.move(40,130)
        self.descrip25.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc25 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc25.move(20,320)
        self.year_disc25.setFont(QtGui.QFont('Impact', 14))

        self.year25 = QLabel("1984",self)
        self.year25.move(170,322)
        self.year25.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by25 = QLabel("DISCOVERED BY:",self)
        self.disc_by25.move(20,370)
        self.disc_by25.setFont(QtGui.QFont('Impact', 14))

        self.author25 = QLabel("Brad Cox and Tom Love",self)
        self.author25.move(150,372)
        self.author25.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm25 = QLabel("PARADIGM:",self)
        self.paradigm25.move(20,420)
        self.paradigm25.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type25 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type25.move(110,422)
        self.paradigm_type25.setFont(QtGui.QFont('Consolas', 13))

class PostScript(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PostScript")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('PostScript.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog26 = QLabel("PostScript", self)
        self.prog26.move(180,70)
        self.prog26.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image26 = QLabel(self)
        pixmap = QPixmap('PostScript.png')
        self.image26.setPixmap(pixmap)
        self.image26.move(460,50)
        self.image26.resize(300,335)

        self.descrip26 = QLabel("     The PostScript (PS) is a page description \nlanguage in the electronic publishing and \ndesktop publishing business. It is a \ndynamically typed, concatenative programming \nlanguage and was created at Adobe Systems. It \nis primarily a language for printing documents \non laser printers, but it can be adapted to \nproduce images on other types of devices.",self)
        self.descrip26.move(40,130)
        self.descrip26.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc26 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc26.move(20,320)
        self.year_disc26.setFont(QtGui.QFont('Impact', 14))

        self.year26 = QLabel("1982",self)
        self.year26.move(170,322)
        self.year26.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by26 = QLabel("DISCOVERED BY:",self)
        self.disc_by26.move(20,370)
        self.disc_by26.setFont(QtGui.QFont('Impact', 14))
        
        self.author26 = QLabel("John Wornock",self)
        self.author26.move(150,372)
        self.author26.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm26 = QLabel("PARADIGM:",self)
        self.paradigm26.move(20,420)
        self.paradigm26.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type26 = QLabel("Scripting Programming Language",self)
        self.paradigm_type26.move(110,422)
        self.paradigm_type26.setFont(QtGui.QFont('Consolas', 13))

class Tcl(QWidget):   
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TCL")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('tcl.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog27 = QLabel("Tool Command Language", self)
        self.prog27.move(150,70)
        self.prog27.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image27 = QLabel(self)
        pixmap = QPixmap('tcl.png')
        self.image27.setPixmap(pixmap)
        self.image27.move(550,50)
        self.image27.resize(192,300)

        self.descrip27 = QLabel("     The Tool Command Language (TCL) is a high-level, \ngeneral-purpose, interpreted, dynamic programming \nlanguage. TCL is a radically simple open-source \ninterpreted programming language that provides common \nfacilities such as variables, procedures, and control \nstructures as well as many useful features that are not \nfound in any other major language.",self)
        self.descrip27.move(40,130)
        self.descrip27.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc27 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc27.move(20,310)
        self.year_disc27.setFont(QtGui.QFont('Impact', 14))

        self.year27 = QLabel("1988",self)
        self.year27.move(170,312)
        self.year27.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by27 = QLabel("DISCOVERED BY:",self)
        self.disc_by27.move(20,360)
        self.disc_by27.setFont(QtGui.QFont('Impact', 14))

        self.author27 = QLabel("John Ousterhout",self)
        self.author27.move(150,362)
        self.author27.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm27 = QLabel("PARADIGM:",self)
        self.paradigm27.move(20,410)
        self.paradigm27.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type27 = QLabel("Scripting Programming Language",self)
        self.paradigm_type27.move(110,412)
        self.paradigm_type27.setFont(QtGui.QFont('Consolas', 13))

class Hypertalk(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Hypertalk")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Hypertalk.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog28 = QLabel("HyperTalk", self)
        self.prog28.move(200,70)
        self.prog28.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image28 = QLabel(self)
        pixmap = QPixmap('Hypertalk.png')
        self.image28.setPixmap(pixmap)
        self.image28.move(470,10)
        self.image28.resize(300,300)

        self.descrip28 = QLabel("     The HyperTalk is a high-level, procedural \nprogramming language and used in conjunction \nwith Apple Computer's HyperCard hypermedia \nprogram by Bill Atkinson. The main target \naudience of HyperTalk was beginning programmers, \nhence HyperTalk programmers were usually called \nauthors, and the process of writing programs was \ncalled 'scripting'. HyperTalk scripts are fairly \nsimilar to written English supported the basic \ncontrol structures of procedural languages.",self)
        self.descrip28.move(40,130)
        self.descrip28.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc28 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc28.move(20,370)
        self.year_disc28.setFont(QtGui.QFont('Impact', 14))

        self.year28 = QLabel("1988",self)
        self.year28.move(170,372)
        self.year28.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by28 = QLabel("DISCOVERED BY:",self)
        self.disc_by28.move(20,420)
        self.disc_by28.setFont(QtGui.QFont('Impact', 14))

        self.author28 = QLabel("John Ousterhout",self)
        self.author28.move(150,422)
        self.author28.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm28 = QLabel("PARADIGM:",self)
        self.paradigm28.move(20,470)
        self.paradigm28.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type28 = QLabel("Scripting Programming Language",self)
        self.paradigm_type28.move(110,472)
        self.paradigm_type28.setFont(QtGui.QFont('Consolas', 13))

class Perl(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PERL")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Perl.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog29 = QLabel("Practical Extraction and Reporting \n\tLanguage (PERL)", self)
        self.prog29.move(40,60)
        self.prog29.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image29 = QLabel(self)
        pixmap = QPixmap('Perl.png')
        self.image29.setPixmap(pixmap)
        self.image29.move(450,80)
        self.image29.resize(300,145)

        self.descrip29 = QLabel("     The Practical Extraction and Reporting \n(PERL) is a general-purpose programming language \noriginally developed for text manipulation and \nnow used for a wide range of tasks including \nsystem administration, web development, network \nprogramming, GUI development, and more.",self)
        self.descrip29.move(40,150)
        self.descrip29.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc29 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc29.move(20,300)
        self.year_disc29.setFont(QtGui.QFont('Impact', 14))

        self.year29 = QLabel("1987",self)
        self.year29.move(170,302)
        self.year29.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by29 = QLabel("DISCOVERED BY:",self)
        self.disc_by29.move(20,350)
        self.disc_by29.setFont(QtGui.QFont('Impact', 14))

        self.author29 = QLabel("Larry Wall ",self)
        self.author29.move(150,352)
        self.author29.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm29 = QLabel("PARADIGM:",self)
        self.paradigm29.move(20,400)
        self.paradigm29.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type29 = QLabel("Scripting Programming Language",self)
        self.paradigm_type29.move(110,402)
        self.paradigm_type29.setFont(QtGui.QFont('Consolas', 13))

class CommonLISP(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Common LISP")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('CommonLISP.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog30 = QLabel("Common LISP", self)
        self.prog30.move(180,70)
        self.prog30.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image30 = QLabel(self)
        pixmap = QPixmap('CommonLISP.png')
        self.image30.setPixmap(pixmap)
        self.image30.move(460,70)
        self.image30.resize(300,203)

        self.descrip30 = QLabel("     The Common Lisp (CL) is a general-purpose \nprogramming language and thus has a large \nlanguage standard including many built-in data \ntypes, functions, macros and other language \nelements, and an object system (Common Lisp \nObject System). Also, it is a dialect of the \nLISP programming language.",self)
        self.descrip30.move(40,130)
        self.descrip30.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc30 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc30.move(20,300)
        self.year_disc30.setFont(QtGui.QFont('Impact', 14))

        self.year30 = QLabel("1984 first appeared, 1994 for ANSI Common LISP",self)
        self.year30.move(170,302)
        self.year30.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by30 = QLabel("DISCOVERED BY:",self)
        self.disc_by30.move(20,350)
        self.disc_by30.setFont(QtGui.QFont('Impact', 14))

        self.author30 = QLabel("ANSI X3J13 Committee",self)
        self.author30.move(150,352)
        self.author30.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm30 = QLabel("PARADIGM:",self)
        self.paradigm30.move(20,400)
        self.paradigm30.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type30 = QLabel("Functional Programming Language",self)
        self.paradigm_type30.move(110,402)
        self.paradigm_type30.setFont(QtGui.QFont('Consolas', 13))

class Erlang(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Erlang")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Erlang.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog31 = QLabel("Erlang", self)
        self.prog31.move(200,70)
        self.prog31.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image31 = QLabel(self)
        pixmap = QPixmap('Erlang.png')
        self.image31.setPixmap(pixmap)
        self.image31.move(460,50)
        self.image31.resize(300,263)

        self.descrip31 = QLabel("     The Erlang is a general-purpose, \nconcurrent, functional programming language, \nand a garbage-collected runtime system. The \nErlang programming language has immutable \ndata, pattern matching, and functional \nprogramming. The sequential subset of the \nErlang language supports eager evaluation, \nsingle assignment, and dynamic typing.",self)
        self.descrip31.move(40,130)
        self.descrip31.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc31 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc31.move(20,320)
        self.year_disc31.setFont(QtGui.QFont('Impact', 14))

        self.year31 = QLabel("1986",self)
        self.year31.move(170,322)
        self.year31.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by31 = QLabel("DISCOVERED BY:",self)
        self.disc_by31.move(20,370)
        self.disc_by31.setFont(QtGui.QFont('Impact', 14))

        self.author31 = QLabel("Ericsson Telecommunication Company",self)
        self.author31.move(150,372)
        self.author31.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm31 = QLabel("PARADIGM:",self)
        self.paradigm31.move(20,420)
        self.paradigm31.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type31 = QLabel("Functional Programming Language",self)
        self.paradigm_type31.move(110,422)
        self.paradigm_type31.setFont(QtGui.QFont('Consolas', 13))

class VisualBASIC(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Visual BASIC")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('VisualBASIC.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog32 = QLabel("Visual BASIC", self)
        self.prog32.move(160,70)
        self.prog32.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image32 = QLabel(self)
        pixmap = QPixmap('VisualBASIC.png')
        self.image32.setPixmap(pixmap)
        self.image32.move(450,50)
        self.image32.resize(300,297)

        self.descrip32 = QLabel("     The Visual BASIC was derived from BASIC, \nis an event-driven programming language and \nenvironment from Microsoft that provides a \ngraphical user interface (GUI) which allows \nprogrammers to modify code by simply dragging \nand dropping objects and defining their behavior \nand appearance",self)
        self.descrip32.move(40,150)
        self.descrip32.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc32 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc32.move(20,320)
        self.year_disc32.setFont(QtGui.QFont('Impact', 14))

        self.year32 = QLabel("1991",self)
        self.year32.move(170,322)
        self.year32.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by32 = QLabel("DISCOVERED BY:",self)
        self.disc_by32.move(20,370)
        self.disc_by32.setFont(QtGui.QFont('Impact', 14))

        self.author32 = QLabel("Alan Cooper",self)
        self.author32.move(150,372)
        self.author32.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm32 = QLabel("PARADIGM:",self)
        self.paradigm32.move(20,420)
        self.paradigm32.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type32 = QLabel("Imperative Programming Language",self)
        self.paradigm_type32.move(110,422)
        self.paradigm_type32.setFont(QtGui.QFont('Consolas', 13))

class Delphi(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Delphi")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Delphi.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog33 = QLabel("Delphi", self)
        self.prog33.move(220,70)
        self.prog33.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image33 = QLabel(self)
        pixmap = QPixmap('Delphi.png')
        self.image33.setPixmap(pixmap)
        self.image33.move(460,50)
        self.image33.resize(300,300)

        self.descrip33 = QLabel("     The Delphi is an event-driven programming \nlanguage based on Object Pascal and an \nassociated integrated development environment \n(IDE) for rapid application development of \ndesktop, mobile, web, and console software, \ncurrently developed and maintained by \nEmbarcadero Technologies.",self)
        self.descrip33.move(40,130)
        self.descrip33.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc33 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc33.move(20,300)
        self.year_disc33.setFont(QtGui.QFont('Impact', 14))

        self.year33 = QLabel("1995",self)
        self.year33.move(170,302)
        self.year33.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by33 = QLabel("DISCOVERED BY:",self)
        self.disc_by33.move(20,350)
        self.disc_by33.setFont(QtGui.QFont('Impact', 14))

        self.author33 = QLabel("Borland",self)
        self.author33.move(150,352)
        self.author33.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm33 = QLabel("PARADIGM:",self)
        self.paradigm33.move(20,400)
        self.paradigm33.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type33 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type33.move(110,402)
        self.paradigm_type33.setFont(QtGui.QFont('Consolas', 13))

class Java(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Java")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Java.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog34 = QLabel("Java", self)
        self.prog34.move(250,70)
        self.prog34.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image34 = QLabel(self)
        pixmap = QPixmap('Java.png')
        self.image34.setPixmap(pixmap)
        self.image34.move(550,50)
        self.image34.resize(300,300)

        self.descrip34 = QLabel("     The Java is a general-purpose programming language \nthat is class-based, object-oriented, and designed to \nhave as few implementation dependencies as possible. \nIt is intended to let application developers “write \nonce, run anywhere” (WORA), meaning that compiled Java \ncode can run on all platforms that support Java without \nthe need for recompilation.",self)
        self.descrip34.move(40,130)
        self.descrip34.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc34 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc34.move(20,310)
        self.year_disc34.setFont(QtGui.QFont('Impact', 14))

        self.year34 = QLabel("1995",self)
        self.year34.move(170,312)
        self.year34.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by34 = QLabel("DISCOVERED BY:",self)
        self.disc_by34.move(20,360)
        self.disc_by34.setFont(QtGui.QFont('Impact', 14))

        self.author34 = QLabel("James Gosling ",self)
        self.author34.move(150,362)
        self.author34.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm34 = QLabel("PARADIGM:",self)
        self.paradigm34.move(20,410)
        self.paradigm34.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type34 = QLabel("Object-Oriented Programming Language",self)
        self.paradigm_type34.move(110,412)
        self.paradigm_type34.setFont(QtGui.QFont('Consolas', 13))

class Python(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Python")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Python.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog35 = QLabel("Python", self)
        self.prog35.move(200,70)
        self.prog35.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image35 = QLabel(self)
        pixmap = QPixmap('Python.png')
        self.image35.setPixmap(pixmap)
        self.image35.move(460,50)
        self.image35.resize(300,300)

        self.descrip35 = QLabel("     Python is an interpreted, high-level, \ngeneral-purpose programming language. Python’s \ndesign philosophy emphasizes code readability \nwith its notable use of significant whitespace. \nIts language constructs and object-oriented \napproach aim to help programmers write clear, \nlogical code for small and large-scale projects.",self)
        self.descrip35.move(40,140)
        self.descrip35.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc35 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc35.move(20,310)
        self.year_disc35.setFont(QtGui.QFont('Impact', 14))

        self.year35 = QLabel("1989",self)
        self.year35.move(170,312)
        self.year35.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by35 = QLabel("DISCOVERED BY:",self)
        self.disc_by35.move(20,360)
        self.disc_by35.setFont(QtGui.QFont('Impact', 14))

        self.author35 = QLabel("Guido van Rossum",self)
        self.author35.move(150,362)
        self.author35.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm35 = QLabel("PARADIGM:",self)
        self.paradigm35.move(20,410)
        self.paradigm35.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type35 = QLabel("Multi-Paradigm Programming Language",self)
        self.paradigm_type35.move(110,412)
        self.paradigm_type35.setFont(QtGui.QFont('Consolas', 13))

class AppleScript(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AppleScript")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('AppleScript.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog36 = QLabel("AppleScript", self)
        self.prog36.move(220,70)
        self.prog36.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image36 = QLabel(self)
        pixmap = QPixmap('AppleScript.png')
        self.image36.setPixmap(pixmap)
        self.image36.move(480,50)
        self.image36.resize(300,300)

        self.descrip36 = QLabel("     The AppleScript is a scripting language \ncreated by Apple Inc. that facilitates automated \ncontrol over scriptable Mac applications. The term \n'AppleScript' may refer to the language itself, to \nan individual script written in the language, or, \ninformally, to the macOS Open ScriptingArchitecture \nthat underlies the language.",self)
        self.descrip36.move(40,130)
        self.descrip36.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc36 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc36.move(20,300)
        self.year_disc36.setFont(QtGui.QFont('Impact', 14))

        self.year36 = QLabel("1993 ",self)
        self.year36.move(170,302)
        self.year36.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by36 = QLabel("DISCOVERED BY:",self)
        self.disc_by36.move(20,350)
        self.disc_by36.setFont(QtGui.QFont('Impact', 14))

        self.author36 = QLabel("Apple Inc.",self)
        self.author36.move(150,352)
        self.author36.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm36 = QLabel("PARADIGM:",self)
        self.paradigm36.move(20,400)
        self.paradigm36.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type36 = QLabel("Scripting Programming Language",self)
        self.paradigm_type36.move(110,402)
        self.paradigm_type36.setFont(QtGui.QFont('Consolas', 13))

class Coldfusion(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Coldfusion")
        self.setGeometry(250,70,800,600)
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog37 = QLabel("ColdFusion", self)
        self.prog37.move(320,70)
        self.prog37.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.descrip37 = QLabel("     The Adobe ColdFusion is a commercial rapid web-application development \nplatform. ColdFusion was originally designed to make it easier to connect simple \nHTML pages to a database. By version 2 (1996), it became a full platform that \nincluded an IDE in addition to a full scripting language.",self)
        self.descrip37.move(40,140)
        self.descrip37.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc37 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc37.move(20,260)
        self.year_disc37.setFont(QtGui.QFont('Impact', 14))

        self.year37 = QLabel("1995",self)
        self.year37.move(170,262)
        self.year37.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by37 = QLabel("DISCOVERED BY:",self)
        self.disc_by37.move(20,310)
        self.disc_by37.setFont(QtGui.QFont('Impact', 14))

        self.author37 = QLabel("Joseph J. Allaire and Adobe System Inc.",self)
        self.author37.move(150,312)
        self.author37.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm37 = QLabel("PARADIGM:",self)
        self.paradigm37.move(20,360)
        self.paradigm37.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type37 = QLabel("Scripting Programming Language",self)
        self.paradigm_type37.move(110,362)
        self.paradigm_type37.setFont(QtGui.QFont('Consolas', 13))

class JavaScript(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("JavaScript")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('JavaScript.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog38 = QLabel("JavaScript", self)
        self.prog38.move(200,70)
        self.prog38.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image38 = QLabel(self)
        pixmap = QPixmap('JavaScript.png')
        self.image38.setPixmap(pixmap)
        self.image38.move(480,50)
        self.image38.resize(300,300)

        self.descrip38 = QLabel("     The JavaScript is high-level, often \njust-in-time compiled, and multi-paradigm. It has \ncurly-bracket syntax, dynamic typing, \nprototype-based object-orientation, and first-class \nfunctions. It is lightweight and most commonly used \nas a part of web pages, whose implementations allow \nclient-side script to interact with the user and \nmake dynamic pages.",self)
        self.descrip38.move(40,140)
        self.descrip38.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc38 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc38.move(20,330)
        self.year_disc38.setFont(QtGui.QFont('Impact', 14))

        self.year38 = QLabel("1995",self)
        self.year38.move(170,332)
        self.year38.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by38 = QLabel("DISCOVERED BY:",self)
        self.disc_by38.move(20,380)
        self.disc_by38.setFont(QtGui.QFont('Impact', 14))

        self.author38 = QLabel("Brendan Eich",self)
        self.author38.move(150,382)
        self.author38.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm38 = QLabel("PARADIGM:",self)
        self.paradigm38.move(20,430)
        self.paradigm38.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type38 = QLabel("Scripting Programming Language",self)
        self.paradigm_type38.move(110,432)
        self.paradigm_type38.setFont(QtGui.QFont('Consolas', 13))

class PHP(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PHP")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('PHP.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog39 = QLabel("Personal Home Page (PHP)", self)
        self.prog39.move(80,70)
        self.prog39.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image39 = QLabel(self)
        pixmap = QPixmap('PHP.png')
        self.image39.setPixmap(pixmap)
        self.image39.move(460,70)
        self.image39.resize(300,157)

        self.descrip39 = QLabel("     The Personal Home Page (PHP) is a popular \ngeneral-purpose scripting language that is \nespecially suited to web development. PHP code \nis usually processed on a web server by a PHP \ninterpreter implemented as a module, a daemon or \nas a Common Gateway Interface (CGI) executable.\n\n     As the language developed and became what \nit is today the acronym changed to be the \nrecursive version, PHP : Hypertext Preprocessor.",self)
        self.descrip39.move(40,120)
        self.descrip39.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc39 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc39.move(20,350)
        self.year_disc39.setFont(QtGui.QFont('Impact', 14))

        self.year39 = QLabel("1994",self)
        self.year39.move(170,352)
        self.year39.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by39 = QLabel("DISCOVERED BY:",self)
        self.disc_by39.move(20,400)
        self.disc_by39.setFont(QtGui.QFont('Impact', 14))

        self.author39 = QLabel("Rasmus Lerdorf ",self)
        self.author39.move(150,402)
        self.author39.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm39 = QLabel("PARADIGM:",self)
        self.paradigm39.move(20,450)
        self.paradigm39.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type39 = QLabel("Scripting Programming Language",self)
        self.paradigm_type39.move(110,452)
        self.paradigm_type39.setFont(QtGui.QFont('Consolas', 13))

class FSharp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("F#")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('FSharp.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog40 = QLabel("F#", self)
        self.prog40.move(220,60)
        self.prog40.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image40 = QLabel(self)
        pixmap = QPixmap('FSharp.png')
        self.image40.setPixmap(pixmap)
        self.image40.move(460,50)
        self.image40.resize(300,300)

        self.descrip40 = QLabel("     The F# is a general purpose, strongly \ntyped, multi-paradigm programming language that \nencompasses functional, imperative, and \nobject-oriented programming methods. F# \nprogramming primarily involves defining types \nand functions that are type-inferred and \ngeneralized automatically.",self)
        self.descrip40.move(40,140)
        self.descrip40.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc40 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc40.move(20,310)
        self.year_disc40.setFont(QtGui.QFont('Impact', 14))

        self.year40 = QLabel("2005",self)
        self.year40.move(170,312)
        self.year40.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by40 = QLabel("DISCOVERED BY:",self)
        self.disc_by40.move(20,360)
        self.disc_by40.setFont(QtGui.QFont('Impact', 14))

        self.author40 = QLabel("Microsoft Corporation and The F# Software Foundation",self)
        self.author40.move(150,362)
        self.author40.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm40 = QLabel("PARADIGM:",self)
        self.paradigm40.move(20,410)
        self.paradigm40.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type40 = QLabel("Functional Programming Language",self)
        self.paradigm_type40.move(110,412)
        self.paradigm_type40.setFont(QtGui.QFont('Consolas', 13))

class Haskell(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Haskell")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Haskell.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog41 = QLabel("Haskell", self)
        self.prog41.move(200,70)
        self.prog41.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image41 = QLabel(self)
        pixmap = QPixmap('Haskell.png')
        self.image41.setPixmap(pixmap)
        self.image41.move(440,60)
        self.image41.resize(300,212)

        self.descrip41 = QLabel("     The Haskell is a general-purpose, \nstatically typed, purely functional programming \nlanguage with type inference and lazy \nevaluation.",self)
        self.descrip41.move(40,140)
        self.descrip41.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc41 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc41.move(20,250)
        self.year_disc41.setFont(QtGui.QFont('Impact', 14))

        self.year41 = QLabel("1990",self)
        self.year41.move(170,252)
        self.year41.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by41 = QLabel("DISCOVERED BY:",self)
        self.disc_by41.move(20,300)
        self.disc_by41.setFont(QtGui.QFont('Impact', 14))

        self.author41 = QLabel("John McCarthy",self)
        self.author41.move(150,302)
        self.author41.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm41 = QLabel("PARADIGM:",self)
        self.paradigm41.move(20,350)
        self.paradigm41.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type41 = QLabel("Functional Programming Language",self)
        self.paradigm_type41.move(110,352)
        self.paradigm_type41.setFont(QtGui.QFont('Consolas', 13))

class CSharp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("C#")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('CSharp.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog42 = QLabel("C#", self)
        self.prog42.move(220,70)
        self.prog42.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image42 = QLabel(self)
        pixmap = QPixmap('CSharp.png')
        self.image42.setPixmap(pixmap)
        self.image42.move(460,50)
        self.image42.resize(300,330)

        self.descrip42 = QLabel("     C# is a general-purpose, multi-paradigm \nprogramming language encompassing strong typing, \nlexically scoped, imperative, declarative, \nfunctional, generic, object-oriented \n(class-based), and component-oriented \nprogramming disciplines.",self)
        self.descrip42.move(40,140)
        self.descrip42.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc42 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc42.move(20,290)
        self.year_disc42.setFont(QtGui.QFont('Impact', 14))

        self.year42 = QLabel("2000",self)
        self.year42.move(170,292)
        self.year42.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by42 = QLabel("DISCOVERED BY:",self)
        self.disc_by42.move(20,340)
        self.disc_by42.setFont(QtGui.QFont('Impact', 14))

        self.author42 = QLabel("Microsoft Corporation",self)
        self.author42.move(150,342)
        self.author42.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm42 = QLabel("PARADIGM:",self)
        self.paradigm42.move(20,390)
        self.paradigm42.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type42 = QLabel("Multi-Paradigm Programming Language",self)
        self.paradigm_type42.move(110,392)
        self.paradigm_type42.setFont(QtGui.QFont('Consolas', 13))

class Scala(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Scala")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Scala.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog43 = QLabel("Scala", self)
        self.prog43.move(200,70)
        self.prog43.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image43 = QLabel(self)
        pixmap = QPixmap('Scala.png')
        self.image43.setPixmap(pixmap)
        self.image43.move(450,100)
        self.image43.resize(300,123)

        self.descrip43 = QLabel("     Scala combines object-oriented and \nfunctional programming in one concise, \nhigh-level language. Scala's static types \nhelp avoid bugs in complex applications, and \nits JVM and JavaScript runtimes let you \nbuild high-performance systems with easy \naccess to huge ecosystems of libraries.",self)
        self.descrip43.move(40,140)
        self.descrip43.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc43 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc43.move(20,310)
        self.year_disc43.setFont(QtGui.QFont('Impact', 14))

        self.year43 = QLabel("2004",self)
        self.year43.move(170,312)
        self.year43.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by43 = QLabel("DISCOVERED BY:",self)
        self.disc_by43.move(20,360)
        self.disc_by43.setFont(QtGui.QFont('Impact', 14))

        self.author43 = QLabel("Martin Odersky",self)
        self.author43.move(150,362)
        self.author43.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm43 = QLabel("PARADIGM:",self)
        self.paradigm43.move(20,410)
        self.paradigm43.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type43 = QLabel("Multi-Paradigm Programming Language",self)
        self.paradigm_type43.move(110,412)
        self.paradigm_type43.setFont(QtGui.QFont('Consolas', 13))

class Groovy(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Groovy")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Groovy.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog44 = QLabel("Groovy", self)
        self.prog44.move(200,70)
        self.prog44.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image44 = QLabel(self)
        pixmap = QPixmap('Groovy.png')
        self.image44.setPixmap(pixmap)
        self.image44.move(460,80)
        self.image44.resize(300,150)

        self.descrip44 = QLabel("     Apache Groovy is a Java-syntax-compatible \nobject-oriented programming language for the Java \nplatform. It is both a static and dynamic language \nwith features similar to those of Python, Ruby, \nand Smalltalk.",self)
        self.descrip44.move(40,140)
        self.descrip44.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc44 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc44.move(20,280)
        self.year_disc44.setFont(QtGui.QFont('Impact', 14))

        self.year44 = QLabel("2007",self)
        self.year44.move(170,282)
        self.year44.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by44 = QLabel("DISCOVERED BY:",self)
        self.disc_by44.move(20,330)
        self.disc_by44.setFont(QtGui.QFont('Impact', 14))

        self.author44 = QLabel("James Strachan",self)
        self.author44.move(150,332)
        self.author44.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm44 = QLabel("PARADIGM:",self)
        self.paradigm44.move(20,380)
        self.paradigm44.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type44 = QLabel("Dynamic Programming Language",self)
        self.paradigm_type44.move(110,382)
        self.paradigm_type44.setFont(QtGui.QFont('Consolas', 13))

class Ruby(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ruby")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Ruby.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog45 = QLabel("Ruby", self)
        self.prog45.move(210,70)
        self.prog45.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image45 = QLabel(self)
        pixmap = QPixmap('Ruby.png')
        self.image45.setPixmap(pixmap)
        self.image45.move(460,50)
        self.image45.resize(300,299)

        self.descrip45 = QLabel("     Ruby is an interpreted, high-level, \ngeneral-purpose programming language. It is \ndynamically typed and uses garbage collection. \nIt supports multiple programming paradigms, \nincluding procedural, object-oriented, \nand functional programming. ",self)
        self.descrip45.move(40,150)
        self.descrip45.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc45 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc45.move(20,300)
        self.year_disc45.setFont(QtGui.QFont('Impact', 14))

        self.year45 = QLabel("Mid-1990's",self)
        self.year45.move(170,302)
        self.year45.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by45 = QLabel("DISCOVERED BY:",self)
        self.disc_by45.move(20,350)
        self.disc_by45.setFont(QtGui.QFont('Impact', 14))

        self.author45 = QLabel("Yukihiro Matsumoto",self)
        self.author45.move(150,352)
        self.author45.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm45 = QLabel("PARADIGM:",self)
        self.paradigm45.move(20,400)
        self.paradigm45.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type45 = QLabel("Dynamic Programming Language",self)
        self.paradigm_type45.move(110,402)
        self.paradigm_type45.setFont(QtGui.QFont('Consolas', 13))

class GO(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GO")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('GO.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog46 = QLabel("Go", self)
        self.prog46.move(210,70)
        self.prog46.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image46 = QLabel(self)
        pixmap = QPixmap('GO.png')
        self.image46.setPixmap(pixmap)
        self.image46.move(430,100)
        self.image46.resize(300,113)

        self.descrip46 = QLabel("     Go is a statically typed, compiled \nprogramming language designed at Google. It \nis also an open source programming language \nthat makes it easy to build simple, reliable, \nand efficient software.",self)
        self.descrip46.move(40,140)
        self.descrip46.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc46 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc46.move(20,270)
        self.year_disc46.setFont(QtGui.QFont('Impact', 14))

        self.year46 = QLabel("2007",self)
        self.year46.move(170,272)
        self.year46.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by46 = QLabel("DISCOVERED BY:",self)
        self.disc_by46.move(20,320)
        self.disc_by46.setFont(QtGui.QFont('Impact', 14))

        self.author46 = QLabel("Robert Griesemer, Rob Pike, and Ken Thompson",self)
        self.author46.move(150,322)
        self.author46.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm46 = QLabel("PARADIGM:",self)
        self.paradigm46.move(20,370)
        self.paradigm46.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type46 = QLabel("Concurrent Programming Language",self)
        self.paradigm_type46.move(110,372)
        self.paradigm_type46.setFont(QtGui.QFont('Consolas', 13))

class Clojure(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Clojure")
        self.setGeometry(250,70,800,600)
        self.setWindowIcon(QIcon('Clojure.ico'))
        oimg = QImage("circuits.jpg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.prog47 = QLabel("Clojure", self)
        self.prog47.move(200,70)
        self.prog47.setFont(QtGui.QFont('Berlin Sans FB', 20))

        self.image47 = QLabel(self)
        pixmap = QPixmap('Clojure.png')
        self.image47.setPixmap(pixmap)
        self.image47.move(460,50)
        self.image47.resize(300,300)

        self.descrip47 = QLabel("     The Clojure is a modern, dynamic, and \nfunctional dialect of the Lisp programming \nlanguage on the Java platform. Also, Clojure \ncombining the approachability and interactive \ndevelopment of a scripting language with an \nefficient and robust infrastructure for \nmultithreaded programming.",self)
        self.descrip47.move(40,150)
        self.descrip47.setFont(QtGui.QFont('Consolas', 13))

        self.year_disc47 = QLabel("YEAR DISCOVERED:",self)
        self.year_disc47.move(20,320)
        self.year_disc47.setFont(QtGui.QFont('Impact', 14))

        self.year47 = QLabel("2007",self)
        self.year47.move(170,322)
        self.year47.setFont(QtGui.QFont('Consolas', 13))

        self.disc_by47 = QLabel("DISCOVERED BY:",self)
        self.disc_by47.move(20,370)
        self.disc_by47.setFont(QtGui.QFont('Impact', 14))

        self.author47 = QLabel("Richard Hickey",self)
        self.author47.move(150,372)
        self.author47.setFont(QtGui.QFont('Consolas', 13))

        self.paradigm47 = QLabel("PARADIGM:",self)
        self.paradigm47.move(20,420)
        self.paradigm47.setFont(QtGui.QFont('Impact', 14))

        self.paradigm_type47 = QLabel("Functional Programming Language",self)
        self.paradigm_type47.move(110,422)
        self.paradigm_type47.setFont(QtGui.QFont('Consolas', 13))

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.title = "Periodic Table of Programming"
        self.x = 30
        self.y = 30
        self.width = 1300
        self.height = 700
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.setWindowIcon(QIcon('program.ico'))
        oimg = QImage("background.jpeg")
        simg = oimg.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        palette = QPalette()
        palette.setBrush(10, QBrush(simg))
        self.setPalette(palette)
        self.setStyleSheet

        self.image = QLabel(self)
        pixmap = QPixmap('paint.png')
        self.image.setPixmap(pixmap)
        self.image.move(690,50)
        self.image.resize(609,200)

# Title
        self.textboxlbl = QLabel("THE PERIODIC TABLE OF PROGRAMMING LANGUAGES",self)
        self.textboxlbl.move(345,10)
        self.textboxlbl.setFont(QtGui.QFont('Impact', 24))
        self.textboxlbl1 = QLabel("Visualization of the evolution of popular programming languages",self)
        self.textboxlbl1.move(440,50)
        self.textboxlbl1.setFont(QtGui.QFont('Perpetua', 14))
# Periodic Table Buttons
        self.button1 = QPushButton("A", self)
        self.button1.setFont(QtGui.QFont('Impact', 14))
        self.button1.setToolTip("Analytical Engine Order Code")
        self.button1.move(50,120)
        self.button1.resize(50,50)
        self.button1.setStyleSheet("background-color: #CD5C5C; border-radius: 5px")
        self.button1.clicked.connect(self.aeocode)

        self.button2 = QPushButton("E", self)
        self.button2.setFont(QtGui.QFont('Impact', 14))
        self.button2.setToolTip("ENIAC Short Code")
        self.button2.move(590,120)
        self.button2.resize(50,50)
        self.button2.setStyleSheet("background-color: #CD5C5C; border-radius: 5px")
        self.button2.clicked.connect(self.eniacscode)

        self.button3 = QPushButton("Ft", self)
        self.button3.setFont(QtGui.QFont('Impact', 14))
        self.button3.setToolTip("Fortran")
        self.button3.move(50,180)
        self.button3.resize(50,50)
        self.button3.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button3.clicked.connect(self.fortran)

        self.button4 = QPushButton("Ag", self)
        self.button4.setFont(QtGui.QFont('Impact', 14))
        self.button4.setToolTip("ALGOL")
        self.button4.move(110,180)
        self.button4.resize(50,50)
        self.button4.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button4.clicked.connect(self.algol)

        self.button5 = QPushButton("Cb", self)
        self.button5.setFont(QtGui.QFont('Impact', 14))
        self.button5.setToolTip("COBOL")
        self.button5.move(530,180)
        self.button5.resize(50,50)
        self.button5.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button5.clicked.connect(self.cobol)

        self.button6 = QPushButton("L", self)
        self.button6.setFont(QtGui.QFont('Impact', 14))
        self.button6.setToolTip("LISP")
        self.button6.move(590,180)
        self.button6.resize(50,50)
        self.button6.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button6.clicked.connect(self.lisp)

        self.button7 = QPushButton("Sn", self)
        self.button7.setFont(QtGui.QFont('Impact', 14))
        self.button7.setToolTip("SNOBOL")
        self.button7.move(50,240)
        self.button7.resize(50,50)
        self.button7.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button7.clicked.connect(self.snobol)

        self.button8 = QPushButton("Bs", self)
        self.button8.setFont(QtGui.QFont('Impact', 14))
        self.button8.setToolTip("BASIC")
        self.button8.move(110,240)
        self.button8.resize(50,50)
        self.button8.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button8.clicked.connect(self.basic)

        self.button9 = QPushButton("Sm", self)
        self.button9.setFont(QtGui.QFont('Impact', 14))
        self.button9.setToolTip("Simula")
        self.button9.move(170,240)
        self.button9.resize(50,50)
        self.button9.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button9.clicked.connect(self.simula)

        self.button10 = QPushButton("P", self)
        self.button10.setFont(QtGui.QFont('Impact', 14))
        self.button10.setToolTip("PL/1")
        self.button10.move(470,240)
        self.button10.resize(50,50)
        self.button10.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button10.clicked.connect(self.plone)

        self.button11 = QPushButton("B", self)
        self.button11.setFont(QtGui.QFont('Impact', 14))
        self.button11.setToolTip("B")
        self.button11.move(530,240)
        self.button11.resize(50,50)
        self.button11.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button11.clicked.connect(self.b)

        self.button12 = QPushButton("Lg", self)
        self.button12.setFont(QtGui.QFont('Impact', 14))
        self.button12.setToolTip("Logo")
        self.button12.move(590,240)
        self.button12.resize(50,50)
        self.button12.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button12.clicked.connect(self.logo)
 
        self.button13 = QPushButton("Fo", self)
        self.button13.setFont(QtGui.QFont('Impact', 14))
        self.button13.setToolTip("Forth")
        self.button13.move(50,300)
        self.button13.resize(50,50)
        self.button13.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button13.clicked.connect(self.forth)

        self.button14 = QPushButton("Pc", self)
        self.button14.setFont(QtGui.QFont('Impact', 14))
        self.button14.setToolTip("Pascal")
        self.button14.move(110,300)
        self.button14.resize(50,50)
        self.button14.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button14.clicked.connect(self.pascal)

        self.button15 = QPushButton("St", self)
        self.button15.setFont(QtGui.QFont('Impact', 14))
        self.button15.setToolTip("Smalltalk")
        self.button15.move(170,300)
        self.button15.resize(50,50)
        self.button15.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button15.clicked.connect(self.smalltalk)

        self.button16 = QPushButton("Sq", self)
        self.button16.setFont(QtGui.QFont('Impact', 14))
        self.button16.setToolTip("SQL")
        self.button16.move(230,300)
        self.button16.resize(50,50)
        self.button16.setStyleSheet("background-color: #FF00FF; border-radius: 5px")
        self.button16.clicked.connect(self.sql)

        self.button17 = QPushButton("Pg", self)
        self.button17.setFont(QtGui.QFont('Impact', 14))
        self.button17.setToolTip("Prolog")
        self.button17.move(290,300)
        self.button17.resize(50,50)
        self.button17.setStyleSheet("background-color: #FF00FF; border-radius: 5px")
        self.button17.clicked.connect(self.prolog)

        self.button18 = QPushButton("C", self)
        self.button18.setFont(QtGui.QFont('Impact', 14))
        self.button18.setToolTip("C")
        self.button18.move(410,300)
        self.button18.resize(50,50)
        self.button18.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button18.clicked.connect(self.c)

        self.button19 = QPushButton("M", self)
        self.button19.setFont(QtGui.QFont('Impact', 14))
        self.button19.setToolTip("Modula")
        self.button19.move(470,300)
        self.button19.resize(50,50)
        self.button19.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button19.clicked.connect(self.modula)

        self.button20 = QPushButton("Ml", self)
        self.button20.setFont(QtGui.QFont('Impact', 14))
        self.button20.setToolTip("ML")
        self.button20.move(530,300)
        self.button20.resize(50,50)
        self.button20.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button20.clicked.connect(self.ml)

        self.button21 = QPushButton("Sc", self)
        self.button21.setFont(QtGui.QFont('Impact', 14))
        self.button21.setToolTip("Scheme")
        self.button21.move(590,300)
        self.button21.resize(50,50)
        self.button21.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button21.clicked.connect(self.scheme)

        self.button22 = QPushButton("Ad", self)
        self.button22.setFont(QtGui.QFont('Impact', 14))
        self.button22.setToolTip("Ada")
        self.button22.move(50,360)
        self.button22.resize(50,50)
        self.button22.setStyleSheet("background-color: #A9A9A9; border-radius: 5px")
        self.button22.clicked.connect(self.ada)

        self.button23 = QPushButton("Cp", self)
        self.button23.setFont(QtGui.QFont('Impact', 14))
        self.button23.setToolTip("C++")
        self.button23.move(110,360)
        self.button23.resize(50,50)
        self.button23.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button23.clicked.connect(self.cpp)

        self.button24 = QPushButton("Ef", self)
        self.button24.setFont(QtGui.QFont('Impact', 14))
        self.button24.setToolTip("Eiffel")
        self.button24.move(170,360)
        self.button24.resize(50,50)
        self.button24.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button24.clicked.connect(self.eiffel)

        self.button25 = QPushButton("Oc", self)
        self.button25.setFont(QtGui.QFont('Impact', 14))
        self.button25.setToolTip("Objective C")
        self.button25.move(230,360)
        self.button25.resize(50,50)
        self.button25.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button25.clicked.connect(self.objectivec)

        self.button26 = QPushButton("Ps", self)
        self.button26.setFont(QtGui.QFont('Impact', 14))
        self.button26.setToolTip("PostScript")
        self.button26.move(290,360)
        self.button26.resize(50,50)
        self.button26.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button26.clicked.connect(self.postscript)

        self.button27 = QPushButton("Tc", self)
        self.button27.setFont(QtGui.QFont('Impact', 14))
        self.button27.setToolTip("Tcl")
        self.button27.move(350,360)
        self.button27.resize(50,50)
        self.button27.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button27.clicked.connect(self.tcl)

        self.button28 = QPushButton("Ht", self)
        self.button28.setFont(QtGui.QFont('Impact', 14))
        self.button28.setToolTip("HyperTalk")
        self.button28.move(410,360)
        self.button28.resize(50,50)
        self.button28.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button28.clicked.connect(self.hypertalk)

        self.button29 = QPushButton("Pp", self)
        self.button29.setFont(QtGui.QFont('Impact', 14))
        self.button29.setToolTip("PHP")
        self.button29.move(470,420)
        self.button29.resize(50,50)
        self.button29.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button29.clicked.connect(self.php)

        self.button30 = QPushButton("Cl", self)
        self.button30.setFont(QtGui.QFont('Impact', 14))
        self.button30.setToolTip("Common LISP")
        self.button30.move(530,360)
        self.button30.resize(50,50)
        self.button30.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button30.clicked.connect(self.commonlisp)

        self.button31 = QPushButton("Er", self)
        self.button31.setFont(QtGui.QFont('Impact', 14))
        self.button31.setToolTip("Erlang")
        self.button31.move(590,360)
        self.button31.resize(50,50)
        self.button31.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button31.clicked.connect(self.erlang)

        self.button32 = QPushButton("Vb", self)
        self.button32.setFont(QtGui.QFont('Impact', 14))
        self.button32.setToolTip("Visual BASIC")
        self.button32.move(50,420)
        self.button32.resize(50,50)
        self.button32.setStyleSheet("background-color: #F0E68C; border-radius: 5px")
        self.button32.clicked.connect(self.visualbasic)

        self.button33 = QPushButton("Dp", self)
        self.button33.setFont(QtGui.QFont('Impact', 14))
        self.button33.setToolTip("Delphi")
        self.button33.move(110,420)
        self.button33.resize(50,50)
        self.button33.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button33.clicked.connect(self.delphi)

        self.button34 = QPushButton("Jv", self)
        self.button34.setFont(QtGui.QFont('Impact', 14))
        self.button34.setToolTip("Java")
        self.button34.move(170,420)
        self.button34.resize(50,50)
        self.button34.setStyleSheet("background-color: #FFA07A; border-radius: 5px")
        self.button34.clicked.connect(self.java)

        self.button35 = QPushButton("Py", self)
        self.button35.setFont(QtGui.QFont('Impact', 14))
        self.button35.setToolTip("Python")
        self.button35.move(230,420)
        self.button35.resize(50,50)
        self.button35.setStyleSheet("background-color: #40E0D0; border-radius: 5px")
        self.button35.clicked.connect(self.python)

        self.button36 = QPushButton("As", self)
        self.button36.setFont(QtGui.QFont('Impact', 14))
        self.button36.setToolTip("AppleScript")
        self.button36.move(290,420)
        self.button36.resize(50,50)
        self.button36.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button36.clicked.connect(self.applescript)

        self.button37 = QPushButton("Cf", self)
        self.button37.setFont(QtGui.QFont('Impact', 14))
        self.button37.setToolTip("Coldfusion")
        self.button37.move(350,420)
        self.button37.resize(50,50)
        self.button37.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button37.clicked.connect(self.coldfusion)

        self.button38 = QPushButton("Js", self)
        self.button38.setFont(QtGui.QFont('Impact', 14))
        self.button38.setToolTip("JavasScript")
        self.button38.move(410,420)
        self.button38.resize(50,50)
        self.button38.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button38.clicked.connect(self.javascript)

        self.button39 = QPushButton("Pl", self)
        self.button39.setFont(QtGui.QFont('Impact', 14))
        self.button39.setToolTip("Perl")
        self.button39.move(470,360)
        self.button39.resize(50,50)
        self.button39.setStyleSheet("background-color: #7FFF00; border-radius: 5px")
        self.button39.clicked.connect(self.perl)

        self.button40 = QPushButton("Fs", self)
        self.button40.setFont(QtGui.QFont('Impact', 14))
        self.button40.setToolTip("F#")
        self.button40.move(530,420)
        self.button40.resize(50,50)
        self.button40.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button40.clicked.connect(self.fsharp)

        self.button41 = QPushButton("Hk", self)
        self.button41.setFont(QtGui.QFont('Impact', 14))
        self.button41.setToolTip("Haskell")
        self.button41.move(590,420)
        self.button41.resize(50,50)
        self.button41.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button41.clicked.connect(self.haskell)

        self.button42 = QPushButton("Cs", self)
        self.button42.setFont(QtGui.QFont('Impact', 14))
        self.button42.setToolTip("C#")
        self.button42.move(170,490)
        self.button42.resize(50,50)
        self.button42.setStyleSheet("background-color: #40E0D0; border-radius: 5px")
        self.button42.clicked.connect(self.csharp)

        self.button43 = QPushButton("Sl", self)
        self.button43.setFont(QtGui.QFont('Impact', 14))
        self.button43.setToolTip("Scala")
        self.button43.move(230,490)
        self.button43.resize(50,50)
        self.button43.setStyleSheet("background-color: #40E0D0; border-radius: 5px")
        self.button43.clicked.connect(self.scala)

        self.button44 = QPushButton("Gv", self)
        self.button44.setFont(QtGui.QFont('Impact', 14))
        self.button44.setToolTip("Groovy")
        self.button44.move(290,490)
        self.button44.resize(50,50)
        self.button44.setStyleSheet("background-color: #FF69B4; border-radius: 5px")
        self.button44.clicked.connect(self.groovy)

        self.button45 = QPushButton("Rb", self)
        self.button45.setFont(QtGui.QFont('Impact', 14))
        self.button45.setToolTip("Ruby")
        self.button45.move(350,490)
        self.button45.resize(50,50)
        self.button45.setStyleSheet("background-color: #FF69B4; border-radius: 5px")
        self.button45.clicked.connect(self.ruby)

        self.button46 = QPushButton("G", self)
        self.button46.setFont(QtGui.QFont('Impact', 14))
        self.button46.setToolTip("GO")
        self.button46.move(410,490)
        self.button46.resize(50,50)
        self.button46.setStyleSheet("background-color: #A9A9A9; border-radius: 5px")
        self.button46.clicked.connect(self.go)

        self.button47 = QPushButton("Cj", self)
        self.button47.setFont(QtGui.QFont('Impact', 14))
        self.button47.setToolTip("Clojure")
        self.button47.move(470,490)
        self.button47.resize(50,50)
        self.button47.setStyleSheet("background-color: #1E90FF; border-radius: 5px")
        self.button47.clicked.connect(self.clojure)
# Mechanical
        self.button01 = QPushButton(self)
        self.button01.move(50,560)
        self.button01.resize(20,20)
        self.button01.setStyleSheet("background-color: #CD5C5C; border-radius: 2px")
        
        self.textboxlbl01 = QLabel("Mechanical",self)
        self.textboxlbl01.move(80,562)
        self.textboxlbl01.setFont(QtGui.QFont('Perpetua', 12))
# Imperative
        self.button02 = QPushButton(self)
        self.button02.move(50,600)
        self.button02.resize(20,20)
        self.button02.setStyleSheet("background-color: #F0E68C; border-radius: 2px")
        self.button02.setToolTip("is a paradigm of computer programming in which the program describes \na sequence of steps that change the state of the computer.")
        
        self.textboxlbl02 = QLabel("Imperative",self)
        self.textboxlbl02.move(80,602)
        self.textboxlbl02.setFont(QtGui.QFont('Perpetua', 12))
# Object Oriented
        self.button03 = QPushButton(self)
        self.button03.move(50,640)
        self.button03.resize(20,20)
        self.button03.setStyleSheet("background-color: #FFA07A; border-radius: 2px")
        self.button03.setToolTip("is a programming paradigm based on the concept of 'objects',which can \ncontain data, in the form of fields (often known as attributes or properties), \nand code, in the form of procedures (often known as methods).")

        self.textboxlbl03 = QLabel("Object Oriented",self)
        self.textboxlbl03.move(80,642)
        self.textboxlbl03.setFont(QtGui.QFont('Perpetua', 12))
# Scripting
        self.button04 = QPushButton(self)
        self.button04.move(270,560)
        self.button04.resize(20,20)
        self.button04.setStyleSheet("background-color: #7FFF00; border-radius: 2px")
        self.button04.setToolTip("is a computer language with a series of commands within a file \nthat is capable of being executed without being compiled.")

        self.textboxlbl04 = QLabel("Scripting",self)
        self.textboxlbl04.move(300,562)
        self.textboxlbl04.setFont(QtGui.QFont('Perpetua', 12))
# Declarative
        self.button05 = QPushButton(self)
        self.button05.move(270,600)
        self.button05.resize(20,20)
        self.button05.setStyleSheet("background-color: #FF00FF; border-radius: 2px")
        self.button05.setToolTip("is a computer programming paradigm that the developer defines what the program \nshould accomplish rather than explicitly defining how it should go about doing so.")

        self.textboxlbl05 = QLabel("Declarative",self)
        self.textboxlbl05.move(300,602)
        self.textboxlbl05.setFont(QtGui.QFont('Perpetua', 12))
# Functional
        self.button06 = QPushButton(self)
        self.button06.move(270,640)
        self.button06.resize(20,20)
        self.button06.setStyleSheet("background-color: #1E90FF; border-radius: 2px")
        self.button06.setToolTip("is a programming paradigm—a style of building the structure and elements\n of computer programs—that treats computation as the evaluation of \nmathematical functions and avoids changing-state and mutable data. ")

        self.textboxlbl06 = QLabel("Functional",self)
        self.textboxlbl06.move(300,642)
        self.textboxlbl06.setFont(QtGui.QFont('Perpetua', 12))
# Dynamic
        self.button07 = QPushButton(self)
        self.button07.move(490,560)
        self.button07.resize(20,20)
        self.button07.setStyleSheet("background-color: #FF69B4; border-radius: 2px")
        self.button07.setToolTip("is both a mathematical optimization method and a computer programming method.")

        self.textboxlbl07 = QLabel("Dynamic",self)
        self.textboxlbl07.move(520,562)
        self.textboxlbl07.setFont(QtGui.QFont('Perpetua', 12))
# Concurrent
        self.button08 = QPushButton(self)
        self.button08.move(490,600)
        self.button08.resize(20,20)
        self.button08.setStyleSheet("background-color: #A9A9A9; border-radius: 2px")
        self.button08.setToolTip("is defined as one which uses the concept of simultaneously executing \nprocesses or threads of execution as a means of structuring \na program.")

        self.textboxlbl08 = QLabel("Concurrent",self)
        self.textboxlbl08.move(520,602)
        self.textboxlbl08.setFont(QtGui.QFont('Perpetua', 12))
# Multi-Paradigm
        self.button09 = QPushButton(self)
        self.button09.move(490,640)
        self.button09.resize(20,20)
        self.button09.setStyleSheet("background-color: #40E0D0; border-radius: 2px")
        self.button09.setToolTip("is a programming languages that supports more than one \nprogramming paradigm.")
        
        self.textboxlbl09 = QLabel("Multi-Paradigm",self)
        self.textboxlbl09.move(520,642)
        self.textboxlbl09.setFont(QtGui.QFont('Perpetua', 12))
# Create Account 
        self.textboxlbl = QLabel(" Let's Get", self)
        self.textboxlbl.move(850, 100)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB', 18))

        self.textboxlbl = QLabel("Started", self)
        self.textboxlbl.move(850,120)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB',36))

        self.textboxlbl = QLabel("Create an account to learn more programming languages", self)
        self.textboxlbl.move(850,170)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB',9))
# first name
        self.textboxlbl = QLabel(" First Name",self)
        self.textboxlbl.move(850,230)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB',10))

        self.textbox1 = QLineEdit(self)
        self.textbox1.move(850,250)
        self.textbox1.resize(130,25)
        self.textbox1.setStyleSheet("background-color: #D8BFD8; border-radius: 10px")
# last name
        self.textboxlbl = QLabel(" Last Name",self)
        self.textboxlbl.move(1000,230)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB',10))

        self.textbox2 = QLineEdit(self)
        self.textbox2.move(1000,250)
        self.textbox2.resize(130,25)
        self.textbox2.setStyleSheet("background-color: #D8BFD8; border-radius: 10px")
# email address
        self.textboxlbl = QLabel(" Email Address",self)
        self.textboxlbl.move(850,290)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB',10))

        self.textbox3 = QLineEdit(self)
        self.textbox3.move(850,310)
        self.textbox3.resize(280,25)
        self.textbox3.setStyleSheet("background-color: #98FB98; border-radius: 10px")
# password
        self.textboxlbl = QLabel(" Password",self)
        self.textboxlbl.move(850,350)
        self.textboxlbl.setFont(QtGui.QFont('Berlin Sans FB',10))

        self.textbox4 = QLineEdit(self)
        self.textbox4.setEchoMode(QLineEdit.Password)
        self.textbox4.move(850,370)
        self.textbox4.resize(280,25)
        self.textbox4.setStyleSheet("background-color: #B0C4DE; border-radius: 10px")
#contact number
        self.textboxlbl5 = QLabel(" Contact Number",self)
        self.textboxlbl5.move(850,410)
        self.textboxlbl5.setFont(QtGui.QFont('Berlin Sans FB',10))

        self.textbox5 = QLineEdit(self)
        self.textbox5.move(850,430)
        self.textbox5.resize(280,25)
        self.textbox5.setStyleSheet("background-color: #FFB6C1; border-radius: 10px")

        self.buttonc = QPushButton("CREATE ACCOUNT", self)
        self.buttonc.setFont(QtGui.QFont('Arial Rounded MT Bold', 9))
        self.buttonc.move(850,480)
        self.buttonc.resize(280,40)
        self.buttonc.setStyleSheet("background-color: #F0E68C; border-radius: 20px")
        self.buttonc.clicked.connect(self.account)

        self.show()

    @pyqtSlot()

    def account(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)

        first_Name = self.textbox1.text()
        last_Name = self.textbox2.text()
        email_Add = self.textbox3.text()
        password = self.textbox4.text()
        con_number = self.textbox5.text()
        self.submitdata(first_Name, last_Name, email_Add, password, con_number)
        
    def submitdata(self, first_Name, last_Name, email_Add, password, con_number):
        submit = QMessageBox.question(self, "Creating Account", "Are you sure you want to submit all the information?", QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        
        if submit == QMessageBox.Yes and first_Name != "" and last_Name != "" and email_Add != "" and password != ""  and con_number != "":
            dataDB = SqliteDict("acc_reg.db", autocommit=True)
            reg_list = dataDB.get('registration',[])
            list_dict = {"First Name": first_Name, "Last Name": last_Name, "Email Address": email_Add, "Password": password, "Contact Number": con_number}
            reg_list.append(list_dict)
            dataDB['registration'] = reg_list
            print(dataDB['registration'])

            QMessageBox.information(self, "Registration", "Registration Successful!", QMessageBox.Ok, QMessageBox.Ok)
        
        elif submit == QMessageBox.No:
            pass
        elif submit == QMessageBox.No and first_Name == "" and last_Name == "" and email_Add == "" and password == "" and con_number == "":
            pass
        elif submit == QMessageBox.No and first_Name == "" or last_Name == "" or email_Add == "" or password == "" or con_number == "":
            QMessageBox.warning(self, "Error","Please fill-in all the blank spaces.", QMessageBox.Ok, QMessageBox.Ok)

        self.textbox1.setText("")
        self.textbox2.setText("")
        self.textbox3.setText("")
        self.textbox4.setText("")
        self.textbox5.setText("")

    def aeocode(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = AEOCode()
        self.w.show()

    def eniacscode(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = ENIACSCode()
        self.w.show()

    def fortran(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Fortran()
        self.w.show()

    def algol(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = ALGOL()
        self.w.show()

    def cobol(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = COBOL()
        self.w.show()

    def lisp(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = LISP()
        self.w.show()

    def snobol(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = SNOBOL()
        self.w.show()

    def basic(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = BASIC()
        self.w.show()

    def simula(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Simula()
        self.w.show()

    def plone(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)

        self.w = PL1()
        self.w.show()

    def b(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = B()
        self.w.show()
    
    def logo(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Logo()
        self.w.show()

    def forth(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Forth()
        self.w.show()

    def pascal(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Pascal()
        self.w.show()

    def smalltalk(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Smalltalk()
        self.w.show()

    def sql(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = SQL()
        self.w.show()

    def prolog(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Prolog()
        self.w.show()

    def c(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = C()
        self.w.show()

    def modula(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Modula()
        self.w.show()

    def ml(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = ML()
        self.w.show()

    def scheme(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Scheme()
        self.w.show()

    def ada(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Ada()
        self.w.show()

    def cpp(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = CPP()
        self.w.show()

    def eiffel(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Eiffel()
        self.w.show()

    def objectivec(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = ObjC()
        self.w.show()

    def postscript(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = PostScript()
        self.w.show()

    def tcl(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)

        self.w = Tcl()
        self.w.show()

    def hypertalk(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Hypertalk()
        self.w.show()

    def perl(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Perl()
        self.w.show()

    def commonlisp(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = CommonLISP()
        self.w.show()

    def erlang(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Erlang()
        self.w.show()

    def visualbasic(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = VisualBASIC()
        self.w.show()

    def delphi(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Delphi()
        self.w.show()

    def java(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Java()
        self.w.show()

    def python(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Python()
        self.w.show()

    def applescript(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = AppleScript()
        self.w.show()

    def coldfusion(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Coldfusion()
        self.w.show()

    def javascript(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = JavaScript()
        self.w.show()

    def php(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = PHP()
        self.w.show()

    def fsharp(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = FSharp()
        self.w.show()

    def haskell(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Haskell()
        self.w.show()

    def csharp(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = CSharp()
        self.w.show()

    def scala(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Scala()
        self.w.show()

    def groovy(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Groovy()
        self.w.show()

    def ruby(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Ruby()
        self.w.show()

    def go(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = GO()
        self.w.show()

    def clojure(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.x,self.y,self.width,self.height)
        self.w = Clojure()
        self.w.show()

    def closeEvent(self, event):
        
        reply = QMessageBox.question(self, 'Confirmation',
            "Are you sure you want to quit?", QMessageBox.Yes | 
            QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    sys.exit(app.exec_())